# 多点触摸

多点触摸就是多个手指一起滑动，直接看效果吧~

![](https://github.com/scwang90/SmartRefreshLayout/raw/master/art/gif_demo_multitouch_1.gif) ![](https://github.com/scwang90/SmartRefreshLayout/raw/master/art/gif_demo_multitouch_2.gif)

