package com.scwang.smart.refresh.layout.listener;

/**
 * 刷新加载组合监听器
 * Created by scwang on 2017/5/26.
 */
public interface OnRefreshLoadMoreListener extends OnRefreshListener, OnLoadMoreListener {
}
