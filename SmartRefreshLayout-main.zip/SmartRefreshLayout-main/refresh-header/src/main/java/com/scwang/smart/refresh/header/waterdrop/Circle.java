package com.scwang.smart.refresh.header.waterdrop;

/**
 * Created by scwang on 2018/6/25.
 * 实心圆
 */
public class Circle {
    public float x;//圆x坐标
    public float y;//圆y坐标
    public float radius;//圆半径
    public int color;//圆的颜色
}