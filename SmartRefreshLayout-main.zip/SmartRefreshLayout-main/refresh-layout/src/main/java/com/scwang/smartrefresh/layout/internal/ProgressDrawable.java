package com.scwang.smartrefresh.layout.internal;

/**
 * 旋转动画
 * Created by scwang on 2017/6/16.
 */
public class ProgressDrawable extends com.scwang.smart.drawable.ProgressDrawable {

}
