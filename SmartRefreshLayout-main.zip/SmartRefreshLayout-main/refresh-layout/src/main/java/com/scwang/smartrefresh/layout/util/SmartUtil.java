package com.scwang.smartrefresh.layout.util;

/**
 * SmartUtil
 * Created by scwang on 2018/3/5.
 */
public class SmartUtil extends com.scwang.smart.refresh.layout.util.SmartUtil {

    private SmartUtil(int type) {
        super(type);
    }

}
