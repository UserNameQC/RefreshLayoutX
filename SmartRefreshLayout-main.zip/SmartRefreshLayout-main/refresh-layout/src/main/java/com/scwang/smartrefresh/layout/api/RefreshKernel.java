package com.scwang.smartrefresh.layout.api;

/**
 * 刷新布局核心功能接口
 * 为功能复杂的 Header 或者 Footer 开放的接口
 * Created by scwang on 2017/5/26.
 */
public interface RefreshKernel extends com.scwang.smart.refresh.layout.api.RefreshKernel {

}
