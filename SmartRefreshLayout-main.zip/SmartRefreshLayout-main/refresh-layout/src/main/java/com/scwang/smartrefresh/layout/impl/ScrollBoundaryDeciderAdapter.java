package com.scwang.smartrefresh.layout.impl;

import com.scwang.smart.refresh.layout.simple.SimpleBoundaryDecider;
import com.scwang.smartrefresh.layout.api.ScrollBoundaryDecider;

/**
 * 滚动边界
 * Created by scwang on 2017/7/8.
 */
public class ScrollBoundaryDeciderAdapter extends SimpleBoundaryDecider implements ScrollBoundaryDecider {

}
