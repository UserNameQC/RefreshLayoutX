package com.scwang.smartrefresh.layout.api;

/**
 * 刷新底部
 * Created by scwang on 2017/5/26.
 */
public interface RefreshFooter extends com.scwang.smart.refresh.layout.api.RefreshFooter {

}
