package com.scwang.smartrefresh.layout.internal;

/**
 * 箭头图像
 * Created by scwang on 2018/2/5.
 */
@SuppressWarnings("unused")
public class ArrowDrawable extends com.scwang.smart.refresh.classics.ArrowDrawable {

}
