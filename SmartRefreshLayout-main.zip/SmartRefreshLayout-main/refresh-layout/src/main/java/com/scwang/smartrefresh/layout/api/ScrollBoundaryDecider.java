package com.scwang.smartrefresh.layout.api;

/**
 * 滚动边界
 * Created by scwang on 2017/7/8.
 */
public interface ScrollBoundaryDecider extends com.scwang.smart.refresh.layout.listener.ScrollBoundaryDecider {
}
