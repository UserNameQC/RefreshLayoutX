package com.scwang.smartrefresh.layout.internal;

/**
 * 画笔 Drawable
 * Created by scwang on 2017/6/16.
 */
public abstract class PaintDrawable extends com.scwang.smart.drawable.PaintDrawable {

}
